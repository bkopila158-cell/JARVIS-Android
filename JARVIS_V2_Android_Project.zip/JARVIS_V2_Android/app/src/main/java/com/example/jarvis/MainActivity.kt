package com.example.jarvis

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.URLEncoder
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var answer: TextView
    private lateinit var input: EditText
    private var ttsReady = false

    private val speechRequestCode = 401\n
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(android.graphics.Color.rgb(5, 15, 29))
        }

        val title = TextView(this).apply {
            text = "J A R V I S"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(72, 220, 255))
        }
        status = label("तयार छु। माइक थिचेर बोल्नुहोस्।", 15f)
        heard = label("तपाईंको आदेश यहाँ देखिन्छ।", 14f)
        answer = label("नमस्ते! म JARVIS हुँ।", 17f)

        val mic = Button(this).apply {
            text = "🎙  बोल्नुहोस्"
            textSize = 18f
            setOnClickListener { startVoiceInput() }
        }
        input = EditText(this).apply {
            hint = "आदेश यहाँ लेख्नुहोस्..."
            setTextColor(android.graphics.Color.WHITE)
            setHintTextColor(android.graphics.Color.LTGRAY)
        }
        val run = Button(this).apply {
            text = "आदेश चलाउनुहोस्"
            setOnClickListener { handleCommand(input.text.toString()) }
        }
        val help = Button(this).apply {
            text = "आदेशका उदाहरण"
            setOnClickListener {
                say("युट्युब खोल, क्यामेरा खोल, गुगल खोल, समय भन, वाइफाइ सेटिङ खोल, वा गीत खोज।")
            }
        }

        page.addView(title, params())
        page.addView(status, params(18))
        page.addView(mic, params(18))
        page.addView(sectionTitle("तपाईंको आदेश"))
        page.addView(heard, params())
        page.addView(sectionTitle("JARVIS को जवाफ"))
        page.addView(answer, params())
        page.addView(input, params(12))
        page.addView(run, params())
        page.addView(help, params())
        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun params(top: Int = 8) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = top }

    private fun label(textValue: String, size: Float) = TextView(this).apply {
        text = textValue
        textSize = size
        gravity = Gravity.CENTER
        setTextColor(android.graphics.Color.WHITE)
        setPadding(8, 12, 8, 12)
    }

    private fun sectionTitle(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(android.graphics.Color.rgb(72, 220, 255))
        setPadding(0, 18, 0, 2)
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts.setLanguage(Locale("ne", "NP"))
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale("hi", "IN"))
            }
        }
    }

    private fun say(message: String) {
        answer.text = message
        if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ne-NP")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS लाई आदेश दिनुहोस्")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try {
            startActivityForResult(intent, speechRequestCode)
            status.text = "सुन्दैछु..."
        } catch (_: Exception) {
            say("यो फोनमा Speech Recognition सेवा उपलब्ध छैन। आदेश लेखेर प्रयास गर्नुहोस्।")
        }
    }


    @Deprecated("Uses the platform speech-recognition activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequestCode) {
            if (resultCode == RESULT_OK) {
                val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                val command = words?.firstOrNull().orEmpty()
                if (command.isNotBlank()) handleCommand(command)
                else say("माफ गर्नुहोस्, आवाज बुझिनँ।")
            } else {
                status.text = "आवाज पहिचान भएन। फेरि प्रयास गर्नुहोस्।"
            }
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            startActivity(launch)
            say("$label खोल्दैछु।")
        } else {
            say("$label एप भेटिएन।")
        }
    }

    private fun webSearch(query: String, youtube: Boolean = false) {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = if (youtube) "https://www.youtube.com/results?search_query=$encoded"
                  else "https://www.google.com/search?q=$encoded"
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        say("खोज्दैछु।")
    }

    private fun handleCommand(raw: String) {
        val q = raw.trim().lowercase(Locale.ROOT)
        if (q.isBlank()) return
        heard.text = raw

        when {
            q.contains("camera") || q.contains("क्यामेरा") || q.contains("फोटो") -> {
                try {
                    startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
                    say("क्यामेरा खोल्दैछु।")
                } catch (_: Exception) { say("क्यामेरा खोल्न सकिनँ।") }
            }
            q.contains("call") || q.contains("फोन गर") || q.contains("कल गर") -> {
                val number = Regex("[+0-9][0-9 -]{6,}").find(raw)?.value?.replace(" ", "")?.replace("-", "")
                if (number != null) {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
                    say("नम्बर Dialer मा राखेको छु। कल गर्नुअघि जाँच गर्नुहोस्।")
                } else say("कसलाई फोन गर्ने? नम्बर लेख्नुहोस्, म Dialer खोलिदिन्छु।")
            }
            q.contains("youtube") || q.contains("युट्युब") -> {
                if (q.contains("खोज") || q.contains("search")) {
                    val term = raw.replace(Regex("(?i)youtube|युट्युब|खोज|search"), "").trim()
                    webSearch(term.ifBlank { "music" }, true)
                } else openApp("com.google.android.youtube", "YouTube")
            }
            q.contains("गीत") || q.contains("music") || q.contains("गाना") ->
                webSearch(raw.replace(Regex("गीत|गाना|खोज|search|music"), "").trim().ifBlank { "नेपाली गीत" }, true)
            q.contains("video") || q.contains("भिडियो") ->
                webSearch(raw.replace(Regex("भिडियो|video|खोज|search"), "").trim().ifBlank { "videos" }, true)
            q.contains("chrome") || q.contains("क्रोम") ->
                openApp("com.android.chrome", "Chrome")
            q.contains("google") || q.contains("गुगल") ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
            q.contains("wifi") || q.contains("वाइफाइ") ->
                openSettings(Settings.Panel.ACTION_WIFI)
            q.contains("bluetooth") || q.contains("ब्लुटुथ") ->
                openSettings(Settings.Panel.ACTION_BLUETOOTH)
            q.contains("setting") || q.contains("सेटिङ") ->
                startActivity(Intent(Settings.ACTION_SETTINGS))
            q.contains("समय") || q.contains("time") -> {
                val time = java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
                say("अहिले समय $time भएको छ।")
            }
            q.contains("मिति") || q.contains("date") ->
                say("आजको मिति " + java.text.SimpleDateFormat("dd MMMM yyyy", Locale("ne", "NP")).format(java.util.Date()) + " हो।")
            q.contains("नमस्ते") || q.contains("hello") || q == "hi" ->
                say("नमस्ते! म JARVIS हुँ। तपाईंलाई के सहयोग गरूँ?")
            q.contains("ai") || q.contains("प्रश्न") || q.contains("chat") ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/")))
            else -> say("यो आदेश अहिले थाहा भएन। मद्दत भन्नुहोस् वा आदेश लेख्नुहोस्।")
        }
    }

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action))
            say("सेटिङ खोल्दैछु।")
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
