# JARVIS Version 2 (Android starter)

यो Kotlin Android starter project हो। यसमा नेपाली voice input (फोनको speech recognition service मार्फत), TTS, केही app launch actions, camera, dialer, YouTube/Google search र Settings panels छन्।

## बनाउने तरिका
1. Code On The Go वा Android Studio मा यो ZIP project खोल्नुहोस्।
2. Gradle sync/build चलाउनुहोस्। आवश्यक Android SDK platform 35 र JDK 17 चाहिन्छ।
3. Run गरेर आफ्नो फोनमा install गर्नुहोस्।
4. पहिलो पटक voice input गर्दा फोनले Speech Recognition app/माइक अनुमति माग्न सक्छ।

## आदेशका उदाहरण
- YouTube खोल
- क्यामेरा खोल
- फोन गर 98XXXXXXXX
- गीत खोज नेपाली गीत
- भिडियो खोज funny cartoon
- Wi-Fi सेटिङ खोल
- Bluetooth सेटिङ खोल
- समय भन

## सीमाहरू
- Voice recognition फोनको speech service मा निर्भर हुन्छ; धेरै अवस्थामा इन्टरनेट चाहिन्छ। Offline speech recognition उपलब्धता र Nepali language pack फोनअनुसार फरक हुन्छ।
- Offline command matching app भित्र हुन्छ, तर आवाजलाई text मा बदल्ने सुविधा offline नहुन सक्छ।
- AI Chat हाल ChatGPT वेबसाइट खोल्ने shortcut हो; पूर्ण in-app AI का लागि API key सुरक्षित राख्ने backend थपэхुपर्छ।
- Android सुरक्षा नियमका कारण एपले Wi-Fi/Bluetooth लाई चुपचाप ON/OFF गर्दैन; Settings panel खोल्छ।
- Phone call ले Dialer खोल्छ, आफैँ कल गर्दैन।
- App launcher मा हाल YouTube र Chrome का उदाहरण छन्। थप एपका package ID थप्न सकिन्छ।

## सुरक्षा
API key APK मा नराख्नुहोस्। AI सेवा प्रयोग गर्दा आफ्नै सुरक्षित backend राख्नुहोस्।
